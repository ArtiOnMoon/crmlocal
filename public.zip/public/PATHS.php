<?php
 $uploads_folder='/media/AZ-Marine_data/crm_uploaded_files/';
?>