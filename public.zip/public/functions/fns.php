<?php
require_once 'functions/main.php';
require_once 'functions/auth.php';
require_once 'functions/db.php';
require_once 'functions/service.php';
require_once 'functions/doc_fns.php';
require_once 'functions/message_fns.php';